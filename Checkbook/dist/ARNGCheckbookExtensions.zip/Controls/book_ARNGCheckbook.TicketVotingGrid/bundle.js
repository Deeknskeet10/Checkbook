/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./TicketVotingGrid/components/TicketVotingGridApp.tsx"
/*!*************************************************************!*\
  !*** ./TicketVotingGrid/components/TicketVotingGridApp.tsx ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TicketVotingGridApp: () => (/* binding */ TicketVotingGridApp)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\nfunction _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }\nfunction _nonIterableRest() { throw new TypeError(\"Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.\"); }\nfunction _unsupportedIterableToArray(r, a) { if (r) { if (\"string\" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return \"Object\" === t && r.constructor && (t = r.constructor.name), \"Map\" === t || \"Set\" === t ? Array.from(r) : \"Arguments\" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }\nfunction _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }\nfunction _iterableToArrayLimit(r, l) { var t = null == r ? null : \"undefined\" != typeof Symbol && r[Symbol.iterator] || r[\"@@iterator\"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }\nfunction _arrayWithHoles(r) { if (Array.isArray(r)) return r; }\nvar __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\n\n\nvar TICKET_ENTITY = \"book_ticket\";\nvar ENDORSEMENT_ENTITY = \"book_ticketendorsement\";\nvar CAST_VOTE_API = \"book_CastVote\";\n/** Property-set aliases declared in ControlManifest.Input.xml. */\nvar ALIAS = {\n  name: \"name\",\n  ticketType: \"ticketType\",\n  ticketStatus: \"ticketStatus\",\n  score: \"score\",\n  owner: \"owner\"\n};\nvar useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.makeStyles)({\n  root: Object.assign(Object.assign(Object.assign({\n    display: \"flex\",\n    flexDirection: \"column\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap(\"12px\")), _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding(\"12px\")), {\n    fontFamily: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.fontFamilyBase\n  }),\n  toolbar: Object.assign(Object.assign({\n    display: \"flex\",\n    alignItems: \"center\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap(\"12px\")), {\n    flexWrap: \"wrap\"\n  }),\n  title: {\n    fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.fontSizeBase500,\n    fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.fontWeightSemibold,\n    marginRight: \"auto\"\n  },\n  list: Object.assign({\n    display: \"flex\",\n    flexDirection: \"column\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap(\"8px\")),\n  row: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({\n    display: \"flex\",\n    alignItems: \"center\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap(\"12px\")), _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding(\"10px\", \"14px\")), _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.borderRadius(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.borderRadiusMedium)), _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.border(\"1px\", \"solid\", _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorNeutralStroke2)), {\n    backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorNeutralBackground1\n  }),\n  voteBox: Object.assign({\n    display: \"flex\",\n    flexDirection: \"column\",\n    alignItems: \"center\",\n    minWidth: \"44px\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap(\"2px\")),\n  arrow: Object.assign(Object.assign({\n    minWidth: \"28px\",\n    height: \"24px\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding(0)), {\n    fontSize: \"16px\",\n    lineHeight: \"16px\"\n  }),\n  arrowActiveUp: {\n    color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorPaletteGreenForeground1\n  },\n  arrowActiveDown: {\n    color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorPaletteRedForeground1\n  },\n  score: {\n    fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.fontWeightSemibold,\n    fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.fontSizeBase300\n  },\n  body: Object.assign(Object.assign({\n    display: \"flex\",\n    flexDirection: \"column\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap(\"4px\")), {\n    minWidth: 0,\n    flexGrow: 1\n  }),\n  meta: Object.assign(Object.assign({\n    display: \"flex\",\n    alignItems: \"center\"\n  }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap(\"8px\")), {\n    flexWrap: \"wrap\"\n  }),\n  metaText: {\n    color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorNeutralForeground3,\n    fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.fontSizeBase200\n  },\n  empty: Object.assign(Object.assign({}, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding(\"24px\")), {\n    textAlign: \"center\",\n    color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorNeutralForeground3\n  })\n});\nfunction getXrm() {\n  var _a;\n  var w = window;\n  return (_a = w.Xrm) !== null && _a !== void 0 ? _a : null;\n}\n/** Strips the {braces} Dataverse wraps around a GUID. */\nfunction bareGuid(id) {\n  return id.replace(/[{}]/g, \"\").toLowerCase();\n}\nfunction num(v) {\n  var n = typeof v === \"number\" ? v : Number(v);\n  return Number.isFinite(n) ? n : 0;\n}\nvar TicketVotingGridApp = props => {\n  var _a, _b;\n  var dataset = props.dataset,\n    webAPI = props.webAPI,\n    navigation = props.navigation,\n    userSettings = props.userSettings,\n    isDisabled = props.isDisabled;\n  var styles = useStyles();\n  var _React$useState = react__WEBPACK_IMPORTED_MODULE_0__.useState(\"all\"),\n    _React$useState2 = _slicedToArray(_React$useState, 2),\n    typeFilter = _React$useState2[0],\n    setTypeFilter = _React$useState2[1];\n  // Per-ticket overlay of score + this user's current vote, applied over the\n  // dataset's (possibly stale) values as the user clicks.\n  var _React$useState3 = react__WEBPACK_IMPORTED_MODULE_0__.useState({}),\n    _React$useState4 = _slicedToArray(_React$useState3, 2),\n    overrides = _React$useState4[0],\n    setOverrides = _React$useState4[1];\n  var _React$useState5 = react__WEBPACK_IMPORTED_MODULE_0__.useState(new Set()),\n    _React$useState6 = _slicedToArray(_React$useState5, 2),\n    busyIds = _React$useState6[0],\n    setBusyIds = _React$useState6[1];\n  var _React$useState7 = react__WEBPACK_IMPORTED_MODULE_0__.useState(null),\n    _React$useState8 = _slicedToArray(_React$useState7, 2),\n    error = _React$useState8[0],\n    setError = _React$useState8[1];\n  var baseRows = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    if (!dataset || dataset.loading) return [];\n    return dataset.sortedRecordIds.map(id => {\n      var _a, _b, _c, _d;\n      var r = dataset.records[id];\n      var typeRaw = r.getValue(ALIAS.ticketType);\n      return {\n        id,\n        name: (_a = r.getValue(ALIAS.name)) !== null && _a !== void 0 ? _a : \"(untitled)\",\n        ticketTypeValue: typeRaw == null ? null : num(typeRaw),\n        ticketTypeLabel: (_b = r.getFormattedValue(ALIAS.ticketType)) !== null && _b !== void 0 ? _b : null,\n        statusLabel: (_c = r.getFormattedValue(ALIAS.ticketStatus)) !== null && _c !== void 0 ? _c : null,\n        score: num(r.getValue(ALIAS.score)),\n        ownerName: (_d = r.getFormattedValue(ALIAS.owner)) !== null && _d !== void 0 ? _d : null\n      };\n    });\n  }, [dataset === null || dataset === void 0 ? void 0 : dataset.loading, dataset === null || dataset === void 0 ? void 0 : dataset.sortedRecordIds, dataset === null || dataset === void 0 ? void 0 : dataset.records]);\n  // Seed the overlay with the caller's existing endorsements so their prior\n  // votes render highlighted on load.\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    var cancelled = false;\n    if (baseRows.length === 0) {\n      setOverrides({});\n      return;\n    }\n    var userId = bareGuid(userSettings.userId);\n    void (() => __awaiter(void 0, void 0, void 0, function* () {\n      var _a, _b;\n      try {\n        var resp = yield webAPI.retrieveMultipleRecords(ENDORSEMENT_ENTITY, \"?$select=book_value,_book_ticket_value&$filter=_book_endorser_value eq \".concat(userId));\n        if (cancelled) return;\n        var mine = new Map();\n        for (var e of resp.entities) {\n          var tid = bareGuid(String((_a = e._book_ticket_value) !== null && _a !== void 0 ? _a : \"\"));\n          if (tid) mine.set(tid, num(e.book_value));\n        }\n        var next = {};\n        for (var b of baseRows) {\n          next[b.id] = {\n            score: b.score,\n            myVote: (_b = mine.get(bareGuid(b.id))) !== null && _b !== void 0 ? _b : 0\n          };\n        }\n        setOverrides(next);\n      } catch (e) {\n        if (!cancelled) setError(\"Could not load your votes: \".concat(e.message));\n      }\n    }))();\n    return () => {\n      cancelled = true;\n    };\n  }, [baseRows, userSettings.userId, webAPI]);\n  var typeOptions = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    var _a;\n    var seen = new Map();\n    for (var b of baseRows) {\n      if (b.ticketTypeValue != null && !seen.has(b.ticketTypeValue)) {\n        seen.set(b.ticketTypeValue, (_a = b.ticketTypeLabel) !== null && _a !== void 0 ? _a : String(b.ticketTypeValue));\n      }\n    }\n    return Array.from(seen.entries()).map(_ref => {\n      var _ref2 = _slicedToArray(_ref, 2),\n        value = _ref2[0],\n        label = _ref2[1];\n      return {\n        value,\n        label\n      };\n    });\n  }, [baseRows]);\n  var rows = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    return baseRows.filter(b => typeFilter === \"all\" || b.ticketTypeValue === typeFilter).map(b => {\n      var _a, _b;\n      var o = overrides[b.id];\n      return Object.assign(Object.assign({}, b), {\n        score: (_a = o === null || o === void 0 ? void 0 : o.score) !== null && _a !== void 0 ? _a : b.score,\n        myVote: (_b = o === null || o === void 0 ? void 0 : o.myVote) !== null && _b !== void 0 ? _b : 0\n      });\n    });\n  }, [baseRows, overrides, typeFilter]);\n  var castVote = react__WEBPACK_IMPORTED_MODULE_0__.useCallback((ticketId, direction) => __awaiter(void 0, void 0, void 0, function* () {\n    var xrm = getXrm();\n    if (!xrm) {\n      setError(\"Voting is only available inside the model-driven app.\");\n      return;\n    }\n    setError(null);\n    setBusyIds(prev => new Set(prev).add(ticketId));\n    try {\n      var request = {\n        TicketId: bareGuid(ticketId),\n        Direction: direction,\n        getMetadata: () => ({\n          boundParameter: null,\n          parameterTypes: {\n            TicketId: {\n              typeName: \"Edm.String\",\n              structuralProperty: 1\n            },\n            Direction: {\n              typeName: \"Edm.Int32\",\n              structuralProperty: 1\n            }\n          },\n          operationType: 0,\n          // 0 = Action\n          operationName: CAST_VOTE_API\n        })\n      };\n      var resp = yield xrm.WebApi.online.execute(request);\n      var body = yield resp.json();\n      setOverrides(prev => Object.assign(Object.assign({}, prev), {\n        [ticketId]: {\n          score: num(body.NewScore),\n          myVote: num(body.UserVote)\n        }\n      }));\n    } catch (e) {\n      setError(\"Vote failed: \".concat(e.message));\n    } finally {\n      setBusyIds(prev => {\n        var next = new Set(prev);\n        next.delete(ticketId);\n        return next;\n      });\n    }\n  }), []);\n  var openTicket = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(ticketId => {\n    void navigation.openForm({\n      entityName: TICKET_ENTITY,\n      entityId: bareGuid(ticketId),\n      openInNewWindow: false\n    });\n  }, [navigation]);\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.FluentProvider, {\n    theme: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.webLightTheme\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.root,\n    style: {\n      width: props.width || undefined\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.toolbar\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Text, {\n    className: styles.title\n  }, \"Ticket Board\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Combobox, {\n    \"aria-label\": \"Filter by ticket type\",\n    placeholder: \"All types\",\n    value: typeFilter === \"all\" ? \"All types\" : (_b = (_a = typeOptions.find(o => o.value === typeFilter)) === null || _a === void 0 ? void 0 : _a.label) !== null && _b !== void 0 ? _b : \"\",\n    selectedOptions: [typeFilter === \"all\" ? \"all\" : String(typeFilter)],\n    onOptionSelect: (_, data) => {\n      var v = data.optionValue;\n      setTypeFilter(v === \"all\" || v == null ? \"all\" : Number(v));\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    value: \"all\"\n  }, \"All types\"), typeOptions.map(o => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: o.value,\n    value: String(o.value)\n  }, o.label))))), error && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.MessageBar, {\n    intent: \"error\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.MessageBarBody, null, error))), (dataset === null || dataset === void 0 ? void 0 : dataset.loading) ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Spinner, {\n    label: \"Loading tickets\\u2026\"\n  })) : rows.length === 0 ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.empty\n  }, \"No tickets to show.\")) : (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.list\n  }, rows.map(row => {\n    var busy = busyIds.has(row.id);\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      key: row.id,\n      className: styles.row\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: styles.voteBox\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Tooltip, {\n      content: \"Upvote\",\n      relationship: \"label\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Button, {\n      appearance: \"subtle\",\n      className: \"\".concat(styles.arrow, \" \").concat(row.myVote === 1 ? styles.arrowActiveUp : \"\"),\n      disabled: isDisabled || busy,\n      onClick: () => void castVote(row.id, 1)\n    }, \"\\u25B2\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: styles.score\n    }, busy ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Spinner, {\n      size: \"tiny\"\n    }) : row.score), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Tooltip, {\n      content: \"Downvote\",\n      relationship: \"label\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Button, {\n      appearance: \"subtle\",\n      className: \"\".concat(styles.arrow, \" \").concat(row.myVote === -1 ? styles.arrowActiveDown : \"\"),\n      disabled: isDisabled || busy,\n      onClick: () => void castVote(row.id, -1)\n    }, \"\\u25BC\"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: styles.body\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Link, {\n      as: \"button\",\n      onClick: () => openTicket(row.id)\n    }, row.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: styles.meta\n    }, row.ticketTypeLabel && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Badge, {\n      appearance: \"tint\",\n      color: \"brand\"\n    }, row.ticketTypeLabel)), row.statusLabel && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Badge, {\n      appearance: \"outline\"\n    }, row.statusLabel)), row.ownerName && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: styles.metaText\n    }, \"by \", row.ownerName)))));\n  })))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TicketVotingGrid/components/TicketVotingGridApp.tsx?\n}");

/***/ },

/***/ "./TicketVotingGrid/index.ts"
/*!***********************************!*\
  !*** ./TicketVotingGrid/index.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TicketVotingGrid: () => (/* binding */ TicketVotingGrid)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_TicketVotingGridApp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/TicketVotingGridApp */ \"./TicketVotingGrid/components/TicketVotingGridApp.tsx\");\n\n\nclass TicketVotingGrid {\n  constructor() {\n    // Empty\n  }\n  init(context, notifyOutputChanged) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(true);\n  }\n  updateView(context) {\n    var props = {\n      dataset: context.parameters.tickets,\n      webAPI: context.webAPI,\n      navigation: context.navigation,\n      userSettings: context.userSettings,\n      isDisabled: context.mode.isControlDisabled,\n      width: context.mode.allocatedWidth\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_TicketVotingGridApp__WEBPACK_IMPORTED_MODULE_1__.TicketVotingGridApp, props);\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // no-op\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TicketVotingGrid/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = (module) => {
/******/ 		const getter = module && module.__esModule ?
/******/ 			() => (module['default']) :
/******/ 			() => (module);
/******/ 		__webpack_require__.d(getter, { a: getter });
/******/ 		return getter;
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./TicketVotingGrid/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ARNGCheckbook.TicketVotingGrid', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TicketVotingGrid);
} else {
	var ARNGCheckbook = ARNGCheckbook || {};
	ARNGCheckbook.TicketVotingGrid = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TicketVotingGrid;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}